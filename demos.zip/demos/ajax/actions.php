<?php
include_once "../../../inc/start.php";
include_once "../../../inc/protect.php";
include_once "../../../modules_extra/demos/base/config.php";

if(empty($_POST['phpaction'])) {
	log_error("Прямой вызов actions.php");
	exit(json_encode(array('status' => '2')));
}

if(isset($_POST['load_demos'])) {
	$start = checkStart($_POST['start']);
	$server_id = checkJs($_POST['server'], "int");
	$map = checkJs($_POST['map']);

	if(empty($server_id) || ((empty($start) and $start != 0))) {
		exit();
	}

	$STH = $pdo->query("SELECT `bans_lim` FROM `config__secondary` LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$row = $STH->fetch();
	$limit = $row->bans_lim;

	$STH = $pdo->prepare("SELECT `servers`.`ip`,`servers`.`port`,`servers`.`name`,`servers__demos`.* FROM `servers`  INNER JOIN `servers__demos` ON `servers`.`id` = `servers__demos`.`server_id` WHERE `servers`.`id` = :server_id LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$STH->execute(array(':server_id' => $server_id));
	$server = $STH->fetch();

	if(empty($server->ip)) {
		exit();
	}

	if(!$pdo2 = db_connect($server->db_host, $server->db_db, $server->db_user, $server->db_pass)) {
		exit('<div class="empty-element">Не удалось подключиться к базе данных</div>');
	}
	set_names($pdo2, $server->db_code);

	if(empty($map)) {
		$STH = $pdo2->prepare("SELECT * FROM `$server->db_table` WHERE `address`=:address ORDER BY `id` DESC LIMIT $start, $limit");
		$STH->setFetchMode(PDO::FETCH_OBJ);
		$STH->execute(array(':address' => $server->ip.":".$server->port));
	} else {
		$STH = $pdo2->prepare("SELECT * FROM `$server->db_table` WHERE `address`=:address AND `$server->db_table`.`map` LIKE :map ORDER BY `id` DESC LIMIT $start, $limit");
		$STH->setFetchMode(PDO::FETCH_OBJ);
		$STH->execute(array(':address' => $server->ip.":".$server->port, ":map" => "%".strip_data($map)."%"));
	}

	$tpl = new Template;
	$tpl->dir = $module['tpl_dir'];

	while($row = $STH->fetch()) {
		$tpl->load_template('line.tpl');

		if(file_exists('../../../files/maps_imgs/'.$row->map.'.jpg')) {
			$row->map_image = '/files/maps_imgs/'.$row->map.'.jpg';
		} else {
			$row->map_image = '/files/maps_imgs/none.jpg';
		}
		if($row->size != 0) {
			$row->size = calculate_size($row->size);
		}

		$tpl->set("{name}", $row->demo_name);
		$tpl->set("{start_time}", expand_date($row->record_start_time, 1));
		$tpl->set("{time}", round(($row->record_end_time - $row->record_start_time) / 60));
		$tpl->set("{t_score}", $row->t_score);
		$tpl->set("{ct_score}", $row->ct_score);
		$tpl->set("{map}", $row->map);
		$tpl->set("{map_image}", $row->map_image);
		$tpl->set("{link}", $server->url.$row->demo_name.'.dem');
		$tpl->set("{size}", $row->size);
		$tpl->compile('content');
		$tpl->clear();
	}

	if(empty($tpl->result['content'])) {
		exit('<div class="empty-element">Записей нет</div>');
	} else {
		$tpl->show($tpl->result['content']);
		$tpl->global_clear();
	}
	exit();
}

if(isset($_POST['load_servers']) && is_admin()) {
	$i = 0;

	$STH = $pdo->query("SELECT `servers`.`id` AS `server_id`,`servers`.`name`,`servers`.`ip`,`port`,`servers__demos`.`server_id` AS `settings_id`,`servers__demos`.`ftp_host`,`servers__demos`.`ftp_login`,`servers__demos`.`ftp_pass`,`servers__demos`.`ftp_port`,`servers__demos`.`ftp_string`,`servers__demos`.`db_host`,`servers__demos`.`db_user`,`servers__demos`.`db_pass`,`servers__demos`.`db_db`,`servers__demos`.`db_code`,`servers__demos`.`db_table`,`servers__demos`.`url`,`servers__demos`.`shelf_life` FROM `servers` LEFT JOIN `servers__demos` ON `servers`.`id` = `servers__demos`.`server_id` WHERE `servers`.`type` = 4 ORDER BY `servers`.`trim`");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	while($row = $STH->fetch()) {
		?>
		<div class="col-md-6">
			<div id="server_<?php echo $row->server_id ?>" class="block">
				<div class="block_head">
					<?php echo $row->name ?> (<?php echo $row->ip ?>:<?php echo $row->port ?>)
				</div>
				<b>Введите ссылку до папки с демо записями</b>
				<input value="<?php echo $row->url ?>" type="text" class="form-control mb-5" id="url<?php echo $row->server_id ?>" maxlength="512" autocomplete="off" placeholder="Пример: http://site.ru/demos/">
				<br>
				<b>Сколько дней хранить демо записи</b>
				<input value="<?php echo $row->shelf_life ?>" type="number" class="form-control mb-5" id="shelf_life<?php echo $row->server_id ?>" maxlength="3" autocomplete="off" placeholder="Количество дней">
				<br>
				<b>Введите данные от базы с демо записями</b>
				<input value="<?php echo $row->db_host ?>" type="text" class="form-control mb-5" id="db_host<?php echo $row->server_id ?>" maxlength="64" autocomplete="off" placeholder="Хост базы данных">
				<input value="<?php echo $row->db_db ?>" type="text" class="form-control mb-5" id="db_db<?php echo $row->server_id ?>" maxlength="32" autocomplete="off" placeholder="Название базы данных">
				<input value="<?php echo $row->db_user ?>" type="text" class="form-control mb-5" id="db_user<?php echo $row->server_id ?>" maxlength="32" autocomplete="off" placeholder="Имя пользователя">
				<input value="<?php echo $row->db_pass ?>" type="password" class="form-control mb-5" id="db_pass<?php echo $row->server_id ?>" maxlength="32" autocomplete="off" placeholder="Пароль пользователя">
				<input value="<?php echo $row->db_table ?>" type="text" class="form-control mb-5" id="db_table<?php echo $row->server_id ?>" maxlength="32" autocomplete="off" placeholder="Название таблицы: auto_recorder">
				<select class="form-control" id="db_code<?php echo $row->server_id ?>">
					<option value="0" <?php if($row->db_code == 0) {
						echo "selected";
					} ?> >Кодировка: стандартная
					</option>
					<option value="1" <?php if($row->db_code == 1) {
						echo "selected";
					} ?> >Кодировка: utf-8
					</option>
					<option value="2" <?php if($row->db_code == 2) {
						echo "selected";
					} ?> >Кодировка: latin1
					</option>
				</select>
				<br>
				<b>Введите данные от FTP-сервера, где сохраняются демо записи</b>
				<input value="<?php echo $row->ftp_host ?>" type="text" class="form-control mb-5" id="ftp_host<?php echo $row->server_id ?>" maxlength="64" autocomplete="off" placeholder="Хост">
				<input value="<?php echo $row->ftp_login ?>" type="text" class="form-control mb-5" id="ftp_login<?php echo $row->server_id ?>" maxlength="32" autocomplete="off" placeholder="Имя пользователя">
				<input value="<?php echo $row->ftp_pass ?>" type="password" class="form-control mb-5" id="ftp_pass<?php echo $row->server_id ?>" maxlength="32" autocomplete="off" placeholder="Пароль пользователя">
				<input value="<?php echo $row->ftp_port ?>" type="number" class="form-control mb-5" id="ftp_port<?php echo $row->server_id ?>" maxlength="5" autocomplete="off" placeholder="Порт: 21">
				<input value="<?php echo $row->ftp_string ?>" type="text" class="form-control mb-5" id="ftp_string<?php echo $row->server_id ?>" maxlength="255" autocomplete="off" placeholder="Путь до каталога с демо записями">

				<div class="mt-10">
					<div id="edit_serv_result<?php echo $row->server_id ?>" class="mt-10"></div>
					<button onclick="demos_edit_server(<?php echo $row->server_id ?>, 0);" type="button" class="btn2">
						Сохранить
					</button>
					<button type="button" class="btn2 btn-cancel" onclick="demos_edit_server(<?php echo $row->server_id ?>, 1);">Очистить</button>
				</div>
			</div>
		</div>
		<?php
		if($i % 2 == 1) {
			echo "<div class='clearfix'></div>";
		}
		$i++;
	}

	if($i == 0) {
		exit ('Серверов нет');
	}
}
if(isset($_POST['edit_server']) && is_admin()) {

	$data = array('server_id'  => array('content' => checkJs($_POST['server_id'], "int"), 'length' => 3),
	              'url'        => array('content' => check($_POST['url'], null), 'length' => 512),
	              'shelf_life' => array('content' => check($_POST['shelf_life'], "int"), 'length' => 3),
	              'db_host'    => array('content' => check($_POST['db_host'], null), 'length' => 64),
	              'db_user'    => array('content' => check($_POST['db_user'], null), 'length' => 32),
	              'db_pass'    => array('content' => check($_POST['db_pass'], null), 'length' => 32),
	              'db_db'      => array('content' => check($_POST['db_db'], null), 'length' => 32),
	              'db_table'   => array('content' => check($_POST['db_table'], null), 'length' => 32),
	              'db_code'    => array('content' => check($_POST['db_code'], "int"), 'length' => 1),
	              'ftp_host'   => array('content' => check($_POST['ftp_host'], null), 'length' => 64),
	              'ftp_login'  => array('content' => check($_POST['ftp_login'], null), 'length' => 32),
	              'ftp_pass'   => array('content' => check($_POST['ftp_pass'], null), 'length' => 32),
	              'ftp_port'   => array('content' => check($_POST['ftp_port'], "int"), 'length' => 5),
	              'ftp_string' => array('content' => check($_POST['ftp_string'], null), 'length' => 255));

	if(empty($data['server_id']['content'])) {
		exit (json_encode(array('status' => '2')));
	}

	if($_POST['clean'] == '1') {
		$STH = $pdo->prepare("DELETE FROM `servers__demos` WHERE `server_id`=:server_id LIMIT 1");
		$STH->execute(array(':server_id' => $data['server_id']['content']));

		exit(json_encode(array('status' => '1')));
	}

	unset($_POST);

	foreach($data as $key => $value) {
		if(empty($value['content']) && $key != 'db_code') {
			exit (json_encode(array('status' => '2', 'input' => $key, 'data' => 'Заполните!')));
		}
		if(mb_strlen($value['content'], 'UTF-8') > $value['length']) {
			exit (json_encode(array('status' => '2', 'input' => $key, 'data' => 'Не более '.$value['length'].' символов!')));
		}
	}

	$SM = new ServersManager;

	if(!$pdo2 = db_connect($data['db_host']['content'], $data['db_db']['content'], $data['db_user']['content'], $data['db_pass']['content'])) {
		exit (json_encode(array('status' => '2', 'alert' => 'Не удалось подключиться к базе данных')));
	}
	if(!check_table($data['db_table']['content'], $pdo2)) {
		exit (json_encode(array('status' => '2', 'alert' => 'Указанная таблица не обнаружена в базе данных')));
	}
	if(!check_column($data['db_table']['content'], $pdo2, 'demo_name')) {
		exit (json_encode(array('status' => '2', 'alert' => 'Неверная структура таблицы')));
	}
	if(!check_column($data['db_table']['content'], $pdo2, 'size')) {
		$pdo2->exec("ALTER TABLE `".$data['db_table']['content']."`  ADD `size` INT( 6 ) NOT NULL DEFAULT '0' AFTER `address`");
	}

	$STH = $pdo2->query("SELECT `demo_name` FROM `".$data['db_table']['content']."` ORDER BY `id` DESC LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$row = $STH->fetch();
	if(empty($row->demo_name)) {
		exit(json_encode(array('status' => '2', 'alert' => 'Таблица пуста')));
	}

	if(substr($data['ftp_string']['content'], -1) != '/') {
		$data['ftp_string']['content'] .= '/';
	}
	if(substr($data['ftp_string']['content'], 0, 1) == '/') {
		$data['ftp_string']['content'] = substr($data['ftp_string']['content'], 1);
	}

	if(!$ftp_connection = $SM->ftp_connection($data['ftp_host']['content'], $data['ftp_port']['content'], $data['ftp_login']['content'], $data['ftp_pass']['content'], 'DEMOS_MODULE')) {
		exit(json_encode(array('status' => '2', 'alert' => 'Не удалось подключиться к FTP серверу')));
	}
	if(!$SM->find_users_file($ftp_connection, $data['ftp_string']['content'].$row->demo_name.'.dem')) {
		exit(json_encode(array('status' => '2',
		                       'alert'  => 'Не удалось обнаружить файлы демо записей на FTP сервере по заданному пути: '.$data['ftp_string']['content'].$row->demo_name.'.dem')));
	}
	$SM->close_ftp($ftp_connection);

	if(substr($data['url']['content'], -1) != '/') {
		$data['url']['content'] .= '/';
	}
	if(!@fopen($data['url']['content'].'/'.$row->demo_name.'.dem', "r")) {
		exit(json_encode(array('status' => '2', 'alert' => 'Не удалось обнаружить файлы демо записей по указанной ссылке')));
	}

	$db_data = array();

	foreach($data as $key => $value) {
		$db_data[$key] = $value['content'];
	}

	$STH = $pdo->prepare("SELECT `server_id` FROM `servers__demos` WHERE `server_id`=:server_id LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$STH->execute(array(':server_id' => $data['server_id']['content']));
	$row = $STH->fetch();
	if(isset($row->server_id)) {
		$STH = $pdo->prepare("UPDATE `servers__demos` SET `ftp_host` = :ftp_host, `ftp_login` = :ftp_login, `ftp_pass` = :ftp_pass, `ftp_port` = :ftp_port, `ftp_string` = :ftp_string, `db_host` = :db_host, `db_user` = :db_user, `db_pass` = :db_pass, `db_db` = :db_db, `db_table` = :db_table, `db_code` = :db_code, `url` = :url, `shelf_life` = :shelf_life WHERE `server_id`=:server_id LIMIT 1");
		$STH->execute($db_data);
	} else {
		$STH = $pdo->prepare("INSERT INTO `servers__demos` (`server_id`, `ftp_host`, `ftp_login`, `ftp_pass`, `ftp_port`, `ftp_string`, `db_host`, `db_user`, `db_pass`, `db_db`, `db_table`, `db_code`, `url`, `shelf_life`) values (:server_id, :ftp_host, :ftp_login, :ftp_pass, :ftp_port, :ftp_string, :db_host, :db_user, :db_pass, :db_db, :db_table, :db_code, :url, :shelf_life)");
		$STH->execute($db_data);
	}

	exit(json_encode(array('status' => '1')));
}
?>