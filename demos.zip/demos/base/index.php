<?php
include_once "modules_extra/demos/base/config.php";

update_demos_info($pdo);

if(isset($_GET['page'])) {
	$paginator['page'] = clean($_GET['page'], "int");
} else {
	$paginator['page'] = 0;
}

$STH = $pdo->query("SELECT `bans_lim` FROM `config__secondary` LIMIT 1");
$STH->setFetchMode(PDO::FETCH_OBJ);
$row = $STH->fetch();
$paginator['limit'] = $row->bans_lim;

if($paginator['page']) {
	$paginator['start'] = ($paginator['page'] - 1) * $paginator['limit'];
} else {
	$paginator['page'] = 0;
	$paginator['start'] = 0;
}

if(isset($_GET['server'])) {
	$server_id = clean($_GET['server'], "int");
	$STH = $pdo->prepare("SELECT `servers`.`ip`,`servers`.`port`,`servers`.`name`,`servers__demos`.* FROM `servers` INNER JOIN `servers__demos` ON `servers`.`id` = `servers__demos`.`server_id` WHERE `servers`.`id` = :server_id LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$STH->execute(array(':server_id' => $server_id));
} else {
	$server_id = 0;
	$STH = $pdo->query("SELECT `servers`.`ip`,`servers`.`port`,`servers`.`name`,`servers__demos`.* FROM `servers` INNER JOIN `servers__demos` ON `servers`.`id` = `servers__demos`.`server_id` ORDER BY `servers`.`trim` LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
}
$server = $STH->fetch();
if(empty($server->server_id)) {
	$error = 'empty';
	$paginator['count'] = 0;
	$paginator['stages'] = "";
	$paginator['page_name'] = "";
} else {
	$error = "";
	$server_id = $server->server_id;
	$paginator['page_name'] = "../demos?server=".$server->server_id."&";

	if(!$pdo2 = db_connect($server->db_host, $server->db_db, $server->db_user, $server->db_pass)) {
		$error = $messages['Unable_connect_to_db'];
	} else {
		$STH = $pdo2->prepare("SELECT COUNT(*) as count FROM `$server->db_table` WHERE `address`=:address LIMIT 1");
		$STH->setFetchMode(PDO::FETCH_OBJ);
		$STH->execute(array(':address' => $server->ip.":".$server->port));
		$row = $STH->fetch();
		$paginator['count'] = $row->count;
	}

	$paginator['stages'] = 3;

	if(($paginator['page'] * $paginator['limit'] - $paginator['count']) > $paginator['limit']) {
		header('Location: ../demos');
		exit();
	}
}

$tpl->load_template('elements/title.tpl');
$tpl->set("{title}", $page->title);
$tpl->set("{name}", $conf->name);
$tpl->compile('title');
$tpl->clear();

$tpl->load_template('head.tpl');
$tpl->set("{title}", $tpl->result['title']);
$tpl->set("{site_name}", $conf->name);
$tpl->set("{image}", $page->image);
$tpl->set("{robots}", $page->robots);
$tpl->set("{type}", $page->kind);
$tpl->set("{description}", $page->description);
$tpl->set("{keywords}", $page->keywords);
$tpl->set("{url}", $page->full_url);
$tpl->set("{other}", $module['to_head']);
$tpl->set("{token}", $token);
$tpl->set("{cache}", $conf->cache);
$tpl->set("{template}", $conf->template);
$tpl->set("{site_host}", $site_host);
$tpl->compile('content');
$tpl->clear();

$menu = $tpl->get_menu($pdo);

$nav = array($PI->to_nav('main', 0, 0),
             $PI->to_nav('demos', 1, 0));
$nav = $tpl->get_nav($nav, 'elements/nav_li.tpl');

if(isset($_SESSION['id'])) {
	include_once "inc/authorized.php";
} else {
	include_once "inc/not_authorized.php";
}

$i = 0;
$data = "";
$STH = $pdo->query("SELECT `servers`.`id`,`servers`.`ip`,`servers`.`port`,`servers`.`name` FROM `servers` INNER JOIN `servers__demos` ON `servers`.`id` = `servers__demos`.`server_id` ORDER BY `servers`.`trim`");
$STH->setFetchMode(PDO::FETCH_OBJ);
while($row = $STH->fetch()) {
	if($row->id == $server_id) {
		$data .= '<li class="active"><a href="../demos?server='.$row->id.'">'.$row->name.'</a></li>';
	} else {
		if($i == 0 and empty($server)) {
			$data .= '<li class="active"><a href="../demos?server='.$row->id.'">'.$row->name.'</a></li>';
		} else {
			$data .= '<li><a href="../demos?server='.$row->id.'">'.$row->name.'</a></li>';
		}
	}
	$i++;
}

$tpl->load_template($module['tpl_dir'].'index.tpl');
$tpl->set("{site_host}", $site_host);
$tpl->set("{template}", $conf->template);
$tpl->set("{page}", $paginator['page']);
$tpl->set("{start}", $paginator['start']);
$tpl->set("{server}", $server_id);
$tpl->set("{error}", $error);
$tpl->set("{servers}", $data);
$tpl->set("{pagination}", $tpl->get_paginator($paginator['page'], $paginator['count'], $paginator['limit'], $paginator['stages'], $paginator['page_name']));
$tpl->compile('content');
$tpl->clear();