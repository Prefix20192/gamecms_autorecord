<?php
$module = array('name'          => 'demos',
                'to_head'       => "<script src=\"$site_host/modules_extra/demos/ajax/ajax.js?v={cache}\"></script>
									<link rel=\"stylesheet\" href=\"$site_host/modules_extra/demos/templates/$conf->template/css/primary.css?v={cache}\">",
                'tpl_dir'       => "../../../modules_extra/demos/templates/$conf->template/tpl/",
                'tpl_dir_admin' => "../../../modules_extra/demos/templates/admin/tpl/");

function update_demos_info($pdo) {
	//Выбираем все сервера, которые подключены к базе и фтп от демок
	$STH_ = $pdo->query("SELECT `servers__demos`.*,`servers`.`ip`,`servers`.`port` FROM `servers` INNER JOIN `servers__demos` ON `servers`.`id` = `servers__demos`.`server_id`");
	$STH_->setFetchMode(PDO::FETCH_OBJ);
	while($server = $STH_->fetch()) {
		//Подключаемся к базе
		if(!$pdo2 = db_connect($server->db_host, $server->db_db, $server->db_user, $server->db_pass)) {
			log_error("DEMOS: Не удалось подключиться к базе данных: ".$server->db_host." | ".$server->db_db." | ".$server->db_user);
			break;
		}
		set_names($pdo2, $server->db_code);

		//Определяем последний id демки, по данному серверу
		$STH = $pdo2->prepare("SELECT `id` FROM `$server->db_table` WHERE `address`=:address ORDER BY `id` DESC LIMIT 1");
		$STH->setFetchMode(PDO::FETCH_OBJ);
		$STH->execute(array(':address' => $server->ip.":".$server->port));
		$row = $STH->fetch();
		if(empty($row->id)) {
			$last_demo_id = 0;
		} else {
			$last_demo_id = $row->id;
		}

		//Если есть демки, которые еще не проверяли заходим в тело условия
		if(($server->last_demo == 0 || $server->last_demo != $last_demo_id) && $last_demo_id !== 0) {
			//Если демки id демок почему то снизился, то обнуляем локальный счетчик
			if($server->last_demo > $last_demo_id) {
				$server->last_demo = 0;
			}

			$SM = new ServersManager;
			//Подключаемся к фтп
			if(!$ftp_connection = $SM->ftp_connection($server->ftp_host, $server->ftp_port, $server->ftp_login, $server->ftp_pass, 'DEMOS_MODULE')) {
				break;
			}
			//Переходим в директорию
			if(!ftp_chdir($ftp_connection, $server->ftp_string)) {
				log_error("DEMOS: Не найдена директория: ".$server->ftp_string." на FTP сервере: ".$server->ftp_host." | ".$server->ftp_login);
				break;
			}

			//Получаем список файлов демо записей на фтп
			$demos_list = ftp_nlist($ftp_connection, '.');

			//Выбираем все записи о демках, которые просрочились
			$STH = $pdo2->prepare("SELECT `id`, `demo_name` FROM `$server->db_table` WHERE ((:now_time - `record_end_time`) > :time) AND `address`=:address");
			$STH->setFetchMode(PDO::FETCH_OBJ);
			$STH->execute(array(':now_time' => time(), ':time' => $server->shelf_life * 24 * 60 * 60, ':address' => $server->ip.":".$server->port));
			while($row = $STH->fetch()) {
				//Удаляем демку с фтп
				$file = $row->demo_name.'.dem';
				if(in_array($file, $demos_list)) {
					if(!ftp_delete($ftp_connection, $file)) {
						log_error("DEMOS: Не удалось удалить демо запись: ".$server->ftp_string.$file." на FTP сервере: ".$server->ftp_host." | ".$server->ftp_login);
					}
				}
			}
			//Удаляем демки с бд
			$STH = $pdo2->prepare("DELETE FROM `$server->db_table` WHERE ((:now_time - `record_end_time`) > :time) AND `address`=:address");
			$STH->execute(array(':now_time' => time(), ':time' => $server->shelf_life * 24 * 60 * 60, ':address' => $server->ip.":".$server->port));

			//Обновляем список демо записей на фтп
			$demos_list = ftp_nlist($ftp_connection, '.');

			//Выбираем все демки, которые мы еще не обрабатывали
			$STH = $pdo2->prepare("SELECT `id`, `demo_name` FROM `$server->db_table` WHERE `id`>:id AND `address`=:address");
			$STH->setFetchMode(PDO::FETCH_OBJ);
			$STH->execute(array(':id' => $server->last_demo, ':address' => $server->ip.":".$server->port));
			while($row = $STH->fetch()) {
				$file = $row->demo_name.'.dem';

				//Если файл демо записи существует, то узнаем и записываем ее размер, иначе удаляем запись о ней из базы
				if(in_array($file, $demos_list)) {
					$size = ftp_size($ftp_connection, $file);
					if($size == -1) {
						$size = 0;
					}

					$STH2 = $pdo2->prepare("UPDATE `$server->db_table` SET `size`=:size WHERE `id`=:id LIMIT 1");
					$STH2->execute(array(':size' => $size, ':id' => $row->id));
				} else {
					$STH2 = $pdo2->prepare("DELETE FROM `$server->db_table` WHERE `id`=:id LIMIT 1");
					$STH2->execute(array(':id' => $row->id));
				}
			}

			//Закрываем фтп
			$SM->close_ftp($ftp_connection);

			//Записываем id последней обработанной демки
			$STH = $pdo->prepare("UPDATE `servers__demos` SET last_demo=:last_demo WHERE `server_id`=:server_id LIMIT 1");
			$STH->execute(array(':last_demo' => $last_demo_id, ':server_id' => $server->server_id));
		}
	}

	return true;
}