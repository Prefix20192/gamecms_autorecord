CREATE TABLE `servers__demos` (
  `server_id` int(3) NOT NULL,
  `ftp_host` varchar(64) DEFAULT NULL,
  `ftp_login` varchar(32) DEFAULT NULL,
  `ftp_pass` varchar(32) DEFAULT NULL,
  `ftp_port` int(5) DEFAULT NULL,
  `ftp_string` varchar(255) DEFAULT NULL,
  `db_host` varchar(64) DEFAULT NULL,
  `db_user` varchar(32) DEFAULT NULL,
  `db_pass` varchar(32) DEFAULT NULL,
  `db_db` varchar(32) DEFAULT NULL,
  `db_table` varchar(32) DEFAULT NULL,
  `db_code` int(1) NOT NULL DEFAULT '1',
  `url` varchar(512) DEFAULT NULL,
  `shelf_life` int(3) NOT NULL DEFAULT '3',
  `last_demo` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
